void dummy(void) {}
